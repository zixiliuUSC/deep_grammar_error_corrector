subword-nmt learn-bpe -s 50000 < train > bpe/code
subword-nmt apply-bpe -c bpe/code < train.src | subword-nmt get-vocab > bpe/vocab.src
subword-nmt apply-bpe -c bpe/code < train.tgt | subword-nmt get-vocab > bpe/vocab.tgt
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.src --vocabulary-threshold 50 < train.src > bpe/train.bpe.src
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.tgt --vocabulary-threshold 50 < train.tgt > bpe/train.bpe.tgt
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.src --vocabulary-threshold 50 < val.src > bpe/val.bpe.src
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.tgt --vocabulary-threshold 50 < val.tgt > bpe/val.bpe.tgt
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.src --vocabulary-threshold 50 < test.src > bpe/test.bpe.src
subword-nmt apply-bpe -c bpe/code --vocabulary bpe/vocab.tgt --vocabulary-threshold 50 < test.tgt > bpe/test.bpe.tgt
