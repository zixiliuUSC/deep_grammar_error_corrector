subword-nmt learn-bpe -s 50000 < train > bpe_single_dict/code
cat train.src train.tgt | subword-nmt apply-bpe -c bpe_single_dict/code | subword-nmt get-vocab > bpe_single_dict/vocab
#subword-nmt apply-bpe -c bpe/code < train.tgt | subword-nmt get-vocab > bpe/vocab.tgt
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < train.src > bpe_single_dict/train.bpe.src
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < train.tgt > bpe_single_dict/train.bpe.tgt
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < val.src > bpe_single_dict/val.bpe.src
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < val.tgt > bpe_single_dict/val.bpe.tgt
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < test.src > bpe_single_dict/test.bpe.src
subword-nmt apply-bpe -c bpe_single_dict/code --vocabulary bpe_single_dict/vocab --vocabulary-threshold 50 < test.tgt > bpe_single_dict/test.bpe.tgt